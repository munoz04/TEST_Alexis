#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 22 15:11:18 2024

@author: soukeina
"""

def exercice1():
    dist=float(input("Distance parcourue :"))
    t=float(input("Temps du parcours :"))
    vitesse=dist/t
    print("La vitesse de parcours de ", dist,"est", vitesse,"Km/h")

def exercice2():
    n1=int(input("Donner un entier"))
    n2=int(input("Donner un entier"))
    n3=int(input("Donner un entier"))
    print("Les carrés sont ", n1*n1, n2**2, pow(n3,2))
    somme =n1+n2+n3
    print("La somme est ",somme)
    moyenne=somme/3
    print("La moyenne est %.3f " % moyenne)
    # pour avoir 3 chiffres après la virgule
#print ("milieur")
def exercice3():
    #Version1
    a=input("Donner un caractère")
    b=input("Donner un caractère")
    print("avant permutation a= ",a,"b=",b)
    temp=a
    a=b 
    b=temp
    print("Après permutation a= ",a,"b=",b)
    #Version2
    a=input("Donner un caractère")
    b=input("Donner un caractère")
    print("avant permutation a= ",a,"b=",b)
    a,b=b,a
    print("Après permutation a= ",a,"b=",b)

def exercice4():
    pSeuil = 2.3
    vSeuil = 7.41
    pression = float(input("Donner pression"))
    volume = float(input("Donner volume"))
    if(pression > pSeuil and volume > vSeuil ):
        print("Arrêt Immédiat")
    elif(pression > pSeuil):
        print("Augmenter le volume de l'enceinte")
    elif(volume > vSeuil ):
        print("Diminuer le volume de l’enceinte")
    else :
        print("Tout va bien")
            
            
def exercice5():
    a=int(input("Donner un appéciation entre 1 et 5"))
    
    if(a>5 or a<1):
        print("ERREUR")
    elif(a<3):
        print(":(")
    elif (a==3):
        print(":|")
    else:
        print(";)")
    

def exercice6():
    a=int(input("Donner un entier"))
    b=int(input("Donner un entier"))
    c=int(input("Donner un entier"))
    
    if(a<b and a<c):
        print("Le + petit est ",a)
    elif(b<a and b<c):
        print("Le + petit est ",b)
    else :
        print("Le + petit est ",c)
    
    print("Version 2")
    print("min : ", min(min(a,b),c))
    print("Version 3")
    print("min : ", min(a,b,c))
    
import math
def exercice7():
    print("Donner les coefficient a,b et c de l'eq")
    a=int(input("a="))
    b=int(input("b="))
    c=int(input("c="))
    delta = b*b-4*a*c
    if(delta >0):
        print("Deux Solutions dans IR")
        x1=(-b-math.sqrt(delta))/(2*a)
        x2=(-b+math.sqrt(delta))/(2*a)
        print(x1)
        print(x2)
    elif(delta == 0):
        print("Une seule solution dans IR")
        x1=-b/(2*a) 
        print(x1)
    else :
        print("Pas de solution dans IR")
        print("2 solution dans C")
        x_r=-b/(2*a)
        x_i=math.sqrt(-delta)/(2*a)
        print(x_r,"-",x_i,".i")
        print(x_r,"+",x_i,".i")

def exercice8():
    h=int(input("Donner un h"))
    m=int(input("Donner un m"))
    s=int(input("Donner un s"))
    print(h,":",m,":",s)
    if(s==59):
        s=0
        if(m==59):  
            m=0
            if(h==23):
                h=0
            else:
                h+=1
        else:
            m+=1
    else:
        s+=1
    print(h,":",m,":",s)   


def exercice9():
    a=int(input("a="))
    b=int(input("b="))
    c=int(input("c="))
    if a==(b+c):
        print(a,'=',b,'+',c)
    elif b==(a+c):
        print(b,'=',a,'+',c)
    elif c==(a+b):
        print(c,'=',a,'+',b)
    else: 
        print("Pas de somme")
        
def exercice10():
    annee = int(input("Entrez l annee a verifier:"))
    if(annee%4==0 and annee%100!=0 or annee%400==0):
        print("L'annee est une annee bissextile!")
    else:
        print("L'annee n'est pas une annee bissextile!")

def exercice11():
    for i in range(1,201):
        if(i%3==0 and not i%5==0):
            print(i)
            
def exercice12():
    n = int(input("Entrez un entier positf:"))
    if(n<0):
        print("Pas de factoreille")
    else :
        res=1
        for i in range (2,n+1):
            res*=i
        print(n,"!=",res)
def exercice13():
    import random
    jouer=True
    scoreJ1=0
    scoreJ2=0
    while(jouer):
        joueur1= random.randint(1,6)
        joueur2= random.randint(1,6)
        s=joueur1+joueur2
        if(s%2==0):#paire
            print("Joueur 1 gagne cette manche")
            scoreJ1+=1
        else: 
            print("Joueur 2 gagne cette manche")
            scoreJ2+=1
        print("Voulez vous rejouer ? O: oui N: non")
        rep=input()
        jouer = True if rep=='O' else False
    if(scoreJ1>scoreJ2):
        print("Joueur 1 gagne la partie")
    elif(scoreJ2>scoreJ1):
        print("Joueur 2 gagne la partie")
    else: print("Match nul")
    
def exercice14():
    import random
    alea= random.randint(1,30)
    print("Deviner un chiffre entre 1 et 30")
    #print(alea)
    for i in range(1,8):#for i in range(7):
        print("Tentative",i)
        val=int(input("?:"))
        if val==alea:
            print("Bravo")
            break
        elif val>alea:
            print("Trop grand")
        else:
            print("Trop petit")
    else:
        print("Perdu :(")
    print("fin")
        
def exercice15():
    nb=0
    a=2
    while nb<10:
        for monDiv in range(2,a):
            print("-",monDiv)
            if(a%monDiv==0):
                break
        else:#si je quitte la boucle sans 
            #break c'est que je n'ai pas 
            # trouvé de diviseur : premier
            print(a)
            nb+=1
        a+=1
    
def exercice16():
    n=int(input("Donner un entier "))
    #première figure
    s=''
    for i in range(n):
        s=s+'*'
    print(s)
    
    
    for i in range(n-2):
        s=''
        s=s+'*'
        for j in range(n-2):
            s=s+' '
        s=s+'*'
        print(s)
    s=''
    for i in range(n):
        s=s+'*'
    print(s) 
    #Deuxième figure
    for i in range (n+1):
        s=''
        for j in range(i):
            s+='*'
        print(s)
    #Troisième figure
    for j in range (1,n+1):
        s=''
        for i in range(n-j):
            s+=' '
        for i in range(2*j-1):
            s+='*'
        for i in range(n-j):
            s+=' '
        print (s)
         
def main():
    print("Donner num exo")
    num=int(input())
    match num:
        case 1:
            exercice1()
        case 2:
            exercice2()
        case 3:
            exercice3();
        case 4:
            exercice4()
        case 5:
            exercice5()
        case 6:
            exercice6()
        case 7:
            exercice7()
        case 8:
            exercice8()
        case 9:
            exercice9()
        case 10:
            exercice10()
        case 11:
            exercice11()
        case 12:
            exercice12()
        case 13:
            exercice13()
        case 14:
            exercice14()
        case 15:
            exercice15()
        case 16:
            exercice16()
        case _:
            print("Under construction")
            
if(__name__=="__main__"): 
    main()

