#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 28 11:55:10 2020

@author: soukeina
"""
choixClient=0
dict_prix={}
dict_noms={}
prix_boisson_choisie=0
nom_boisson_choisie=""
piecesMonnaie=(5,10,20,50,30)




def affMenu():
    print("** DISTRIBUTEUR DE BOISSONS **")
    print("Faites votre choix et validez!")
    print("1. Café noir...........(30 P)")
    print("2. Café au lait........(25 P)")
    print("3. Thé.................(20 P)")
    print("4. Chocolat au lait....(45 P)")
    print("5. Cappuccino..........(40 P)")
    print("0. Annuler")

def dic_menu_nom():
    d=dict()
    d[1]="Café noir"
    d[2]="Café au lait"
    d[3]="Thé"
    d[4]="Chocolat au lait"
    d[5]="Cappuccino"
    return d

def dic_menu_prix():
    d=dict()
    d[1]=30
    d[2]=25
    d[3]=20
    d[4]=45
    d[5]=40
    return d

def lireChoix():
    print("...")
    c=int(input())
    return c

def reste_op(r):
    d_reste=dict()
    d_reste[50]=r//50
    r=r%50
    d_reste[20]=r//20  
    r=r%20
    d_reste[10]=r//10
    r=r%10
    d_reste[5]=r//5
    #return (d_reste)
    
    dd_reste={}
    for i,j in d_reste.items():
        if(j!=0):
            dd_reste[i]=j
    #print(dd_reste)
    
    return dd_reste
    
    

#Distributeur 
def run():
    while(True):
        affMenu()
        choixClient=lireChoix()
        dict_noms=dic_menu_nom()
        dict_prix=dic_menu_prix()
        if(choixClient!=0):
            #print(choixClient)
            #print(dictionnaireMenu)
            #print(dictionnaireMenu_code)
            prix_boisson_choisie=dict_prix[choixClient]
            nom_boisson_choisie=dict_noms[choixClient]
            
            print("Vous avez choisi",nom_boisson_choisie,"veuillez introduire",
                  prix_boisson_choisie,"P")
            print("Le distributeur accepte les pièces : ",piecesMonnaie)
            somme_piecesfornies=0
            encore=prix_boisson_choisie
            while (somme_piecesfornies<prix_boisson_choisie):
                p=int(input("$:"))
                encore-=p
                somme_piecesfornies+=p
                if(somme_piecesfornies<prix_boisson_choisie):
                    print("encore ",encore)
                
            print("Vous avez introduits",somme_piecesfornies,"P")
            print("Votre boisson est servie")
            reste=somme_piecesfornies-prix_boisson_choisie
            
            if(reste>0):
                print("Veuillez récupérer votre reste (",reste,")...Bon appétit")
                print("Vos pièces sont",reste_op(reste))
            else:
                print("Bon appétit")
            #marche=input()
            print()
            print()
            print()
    print("FIN")
