#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 22 15:11:18 2024

@author: soukeina
"""
# %% les focntions
def mul(n : int):
    for i in range(11):
        print(n,"x", i,"=", n*i)
        
def pairV1(m,n):
    if m>n:
        m,n=n,m#permutation
    for i in range (m,n+1):
        if(i%2==0):
            print(i)

def pairV2(m,n):
    if m>n:
        m,n=n,m#permutation
    deb= m if m%2==0 else m+1
    for i in range (deb,n+1,2):
        print(i)  
        
def premierV1(a):
    print("Version 1")
    nombreDiviseur=0
    for monDiv in range(2,a):
        if(a%monDiv==0):
            nombreDiviseur+=1
            break
    print(nombreDiviseur)
    if(nombreDiviseur==0):
        return True
    else: 
        return False
    
def premierV2(a):
    print("Version 2")
    for monDiv in range(2,a):
        if(a%monDiv==0):          
            return False
    return True

def premierV3(a):
    print("Version 2")
    for monDiv in range(2,a):
        if(a%monDiv==0):          
            break
    else : 
        return True
    return False

def factorielle(n):
    if(n<0):
        print("Pas de factoreille")
    else :
        res=1
        for i in range (2,n+1):
            res*=i
        print(n,"!=",res)
        
#%% structures avancée
def les_listes():
    #Application sur les listes

    L = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    for valeur in L:
        print(valeur)
    #print(L)
    longueur=len(L)
    print(longueur)
    for i in range(0,longueur):
        L[i]=L[i]+1
    '''
    #2eme version
    L2= [23, 115, -2, 53, 144, 5845, 1476, 157, 58, 9]
    M=list()
    for i in L2:
        M.append(i+1)
        print(M)
    L2=M
    print(L2)
    '''
    L.append(11)
    L.append(12)
    L.append(13)
    #ou bien
    #L.extend([12,13])
    print(L)
    print("Premier elet", L[0])
    print("2 Premier", L[0:2])#print("2 Premier", L[:2])
    print("Dernier", L[-1:])
    print("2 derniers", L[-2:])
    pair=list()
    impair=list()
    for i in L:
        if(i%2==0):
            pair.append(i)
        else:
            impair.append(i)
    print("L ",L)
    print("P ",pair)
    print("I ",impair)
    #Ajouter 200 après 145
    if(145 in L):
        p=L.index(3)
        print(p)
        L.insert(p+1,3.5)
    print(L)
    #supprimer(158)
    if(3.5 in L):
        p=L.index(3.5)
        del(L[p])
        #ou
        #L.remove(3.5)
    print (L)
    L.reverse()
    print(L)
    nb=int(input('Donner un nombre'))
    if( nb in L):
        print(nb, "est dans la liste")
    else:
        print(nb, "n'est pas dans la liste")

def les_strs():
    #application str()

    ch=input('Donner un texte')
    print(ch)
    l=ch.split(' ')
    print(l)
    print("nombre de mots" , len(l))
    
def les_dicts():
    #Application sur les dictionnaires
    ventes={"Dupont":14, "Hervy":19, "Geoffroy":15, "Layec":21}

    print(ventes)

    #Ajouter dans un dictionnaire à condition que la clef n'existe pas
    ventes["ASoukeina"]=200
    print(ventes)
    ventes["Hervy"]=200 # Modif si la clef existe
    print(ventes)

    print("Les clefs",ventes.keys())
    #Les clefs dict_keys(['Dupont', 'Hervy', 'Geoffroy', 'Layec', 'Soukeina'])
    print("Les valeurs",ventes.values())
    #Les valeurs dict_values([14, 100, 15, 21, 200])
    print("Les couples ", ventes.items())
    #Les couples  dict_items([('Dupont', 14), ('Hervy', 100), (....

    #total des ventes
    total=0
    for  valeur in ventes.values():
        total = total+valeur
        print(valeur)

    print("Le total des ventes est", total)
    # le plus grand chiffre d'affaires
    chaff=max(ventes.values())
    print(chaff)
    empp=list()
    for emp, chiffre in ventes.items():
        if(chiffre==chaff):
            print(emp)
            empp.append(emp)

    print(empp)
    print(sorted(empp))

#%% main
def main():
    print("Donner num exo")
    num=int(input())
    match num:
        case 1:
            n= int(input("Donner un entier positif "))
            while(n<0):
                n= int(input("Donner un entier positif "))
            mul(n)
        case 2:
            m= int(input("Donner deb"))
            n= int(input("Donner fin"))
            pairV1(m,n)
            pairV2(m,n)
        case 3:
            n= int(input("Donner un entier"))
            x=premierV1(n)
            print(x)
            x=premierV2(n)
            print(x)
            x=premierV3(n)
            print(x)
        case 4:
            n = int(input("Entrez un entier positf:"))
            factorielle(n)
        case 5:
            les_listes()
        case 6:
            les_strs()
        case 7:
            les_dicts()
        case 8:
            import DistributeurBoissonV1 as dist
            dist.run()
        case _:
            print("Under construction")
            
            
if(__name__=="__main__"): 
    main()
