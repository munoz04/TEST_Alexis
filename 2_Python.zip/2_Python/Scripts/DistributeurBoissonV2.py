2#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 28 11:55:10 2020

@author: soukeina
"""
choixClient=0
nombre_boissons=0
dict_prix={}
dict_noms={}
prix_boisson_choisie=0
nom_boisson_choisie=""
piecesMonnaie=(5,10,20,50)
marche=1
choixClient=-1
def chargement_menu():
    F=open("menu.txt","r")
    lignes= F.readlines()
    F.close()
    return lignes

def dic_menu_nom_file(l):
    j=1
    nombre_boissons=len(l)
    print(nombre_boissons)
    for i in l:
        p_sep=i.index('-')
        nom_b=i[0:p_sep]
        prix_b=int(i[p_sep+1:])
        dict_prix[j]=prix_b
        dict_noms[j]=nom_b
        j+=1
    print(dict_noms,dict_prix)
 
def affMenu(l):
    nombre_boissons=len(l)
    print("** DISTRIBUTEUR DE BOISSONS **")
    print("Faites votre choix et validez!")
    for i in range (1,nombre_boissons+1):
        print(i,". ",dict_noms[i],"...........(",dict_prix[i]," P)")
    print("0 .  Annuler")


def lireChoix():
    print("...")
    c=int(input())
    return c
def reste_op(r):
    d_reste=dict()
    d_reste[50]=r//50
    r=r-d_reste[50]*50
    d_reste[20]=r//20
    r=r-d_reste[20]*20
    d_reste[10]=r//10
    r=r-d_reste[10]*10
    d_reste[5]=r//5
    #print(d_reste)
    dd_reste={}
    for i,j in d_reste.items():
        if(j!=0):
            dd_reste[i]=j
    #print(dd_reste)
    return dd_reste


#Distributeur 
while(True):
    liste_menu=chargement_menu()
    dic_menu_nom_file(liste_menu)
    affMenu(liste_menu)
    choixClient=lireChoix()
    if(choixClient!=0):
       
        prix_boisson_choisie=dict_prix[choixClient]
        nom_boisson_choisie=dict_noms[choixClient]
        
        print("Vous avez choisi",nom_boisson_choisie,"veuillez introduire", prix_boisson_choisie,"P")
        print("Le distributeur accepte les pièces : ",piecesMonnaie)
        somme_piecesfornies=0
        encore=prix_boisson_choisie
        while (somme_piecesfornies<prix_boisson_choisie):
            p=int(input("$:")) 
            if p in piecesMonnaie:
                encore-=p
                somme_piecesfornies+=p
                if(somme_piecesfornies<prix_boisson_choisie):
                    print("encore ",encore)
            else:
                 print("Pièce non acceptée")
        print("Vous avez introduits",somme_piecesfornies,"P")
        print("Votre boisson est servie")
        reste=somme_piecesfornies-prix_boisson_choisie
        
        if(reste>0):
            print("Veuillez récupérer votre reste (",reste,")...Bon appétit")
            print("Vos pièces sont",reste_op(reste))
        else:
            print("Bon appétit")
        #marche=input()
        print()
        print()
        print()
     
print("FIN")